<?php 
session_start();
require_once('../config/connect.php');
if(!isset($_SESSION['username'])||$_SESSION['position']!=1){
	header('Location: ../index.php');

}
if(isset($_POST) & !empty($_POST)){
	$email = mysqli_real_escape_string($connection, $_POST['email']);
	$password = $_POST['password'];
	$position = $_POST['position'];
	$information = $_POST['information'];
	$fullname = $_POST['fullname'];

if(isset($_POST['ok'])){ // Người dùng đã ấn submit
      if($_FILES['file']['name'] != NULL){ // Đã chọn file
           // Tiến hành code upload file
		   if($_FILES['file']['type'] == "image/jpeg"
			|| $_FILES['file']['type'] == "image/png"
			|| $_FILES['file']['type'] == "image/gif"){
			  // là file ảnh
			  // Tiến hành code upload
			  if($_FILES['file']['size'] > 1048576){
			      echo "File không được lớn hơn 1mb";
			  }else{
			      // file hợp lệ, tiến hành upload
			      $path = "../file_upload/img/avatar/"; // ảnh upload sẽ được lưu vào thư mục data
			      $tmp_name = $_FILES['file']['tmp_name'];
			      $name = $_FILES['file']['name'];
			      $type = $_FILES['file']['type']; 
			      $size = $_FILES['file']['size']; 
			      // Upload file
			      move_uploaded_file($tmp_name,$path.$name);
			      
			  }
			}else{
			  // không phải file ảnh
			  echo "Kiểu file không hợp lệ";
			}
	  }else{
           echo "Vui lòng chọn file";
      }
  }
  	$linkimg = $path.$name;
  	$id=$_GET['id'];
$sql = "UPDATE `login` SET email ='$email', fullname ='$fullname', password ='$password', information ='$information', position ='$position', linkimg ='$linkimg' where id = '$id'";
	$result = mysqli_query($connection, $sql);
	if($result){
		$smsg = "User update successfull";
		 header('Location:index.php');
	}else{
		$fmsg = "User update failed";
	}
}


?>